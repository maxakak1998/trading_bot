# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file
# --- Do not remove these libs ---
from datetime import datetime
from typing import Optional
import numpy as np
import pandas as pd
from pandas import DataFrame
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter, CategoricalParameter
import logging
from pandas import DataFrame
import pandas_ta as ta
import sys
from pathlib import Path

# Add strategies directory to path to import local modules
sys.path.append(str(Path(__file__).parent))
from indicators.smc_indicators import SMCIndicators

logger = logging.getLogger(__name__)
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

class FreqAIStrategy(IStrategy):
    """
    FreqAI Strategy example.
    """
    INTERFACE_VERSION = 3
    
    # Minimal ROI designed for the strategy.
    minimal_roi = {
        "60": 0.01,
        "30": 0.03,
        "0": 0.05
    }

    # Risk Management
    stoploss = -0.05
    trailing_stop = False
    
    # Leverage calculation:
    # Target Risk per Trade = 20% of Stake (Margin)
    # Loss = Stake * Leverage * Stoploss_Price_Dist
    # 0.20 * Stake = Stake * Leverage * Stoploss_Price_Dist
    # Leverage = 0.20 / Stoploss_Price_Dist
    
    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str], side: str,
                 **kwargs) -> float:
        """
        Customize leverage for each new trade.
        """
        risk_per_trade = 0.20  # 20% loss allowed on margin
        stoploss_dist = abs(self.stoploss)
        
        # Calculate leverage
        # Example: Stoploss 5% (0.05) -> Leverage = 0.20 / 0.05 = 4x
        # Example: Stoploss 1% (0.01) -> Leverage = 0.20 / 0.01 = 20x
        
        target_leverage = risk_per_trade / stoploss_dist
        
        # Cap leverage at max_leverage or a safe limit (e.g. 20x)
        final_leverage = min(target_leverage, max_leverage, 20.0)
        
        return final_leverage
    
    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: datetime,
                       current_rate: float, current_profit: float, **kwargs) -> float:
        """
        Custom stoploss logic, based on ATR (Average True Range).
        Returns a negative percentage value relative to current_rate.
        
        High volatility (high ATR) → Wider stoploss
        Low volatility (low ATR) → Tighter stoploss
        """
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        last_candle = dataframe.iloc[-1].squeeze()
        
        # Get ATR from last candle
        atr = last_candle.get('atr', 0)
        
        if atr > 0 and current_rate > 0:
            # Stoploss = -2 * (ATR / current_rate)
            # Example: ATR = 2000, Price = 40000 → SL = -2 * (2000/40000) = -10%
            dynamic_sl = -2.0 * (atr / current_rate)
            
            # Cap between -15% (max loss) and -2% (min protection)
            return max(dynamic_sl, -0.15, min(dynamic_sl, -0.02))
        
        # Fallback to static stoploss if ATR not available
        return self.stoploss
    
    def custom_stake_amount(self, pair: str, current_time: datetime, current_rate: float,
                           proposed_stake: float, min_stake: Optional[float], max_stake: float,
                           leverage: float, entry_tag: Optional[str], side: str,
                           **kwargs) -> float:
        """
        Customize stake amount for each trade based on AI confidence.
        
        Logic:
        - Low confidence (0.5-0.6): 50% of base stake (25 USDT)
        - Medium confidence (0.6-0.8): 100% of base stake (50 USDT)
        - High confidence (>0.8): 120% of base stake (60 USDT)
        """
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        last_candle = dataframe.iloc[-1].squeeze()
        
        # Get AI confidence score (prediction mean)
        ai_confidence = last_candle.get('&s-up_or_down_mean', 0.5)
        
        # Scale stake based on confidence
        if ai_confidence > 0.8:
            stake_multiplier = 1.2  # High confidence: 120%
        elif ai_confidence > 0.6:
            stake_multiplier = 1.0  # Medium confidence: 100%
        else:
            stake_multiplier = 0.5  # Low confidence: 50%
        
        final_stake = proposed_stake * stake_multiplier
        
        # Ensure within min/max bounds
        if min_stake:
            final_stake = max(final_stake, min_stake)
        final_stake = min(final_stake, max_stake)
        
        return final_stake

    # Timeframe
    timeframe = '5m'
    process_only_new_candles = True
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    # FreqAI attributes
    can_short = False

    def detect_market_regime(self, dataframe: DataFrame) -> DataFrame:
        """
        Classify market regime: TREND, SIDEWAY, or VOLATILE
        
        Logic:
        - ADX > 25 + BB Width > 0.04 → TREND (strong directional movement)
        - ADX < 20 + BB Width < 0.02 → SIDEWAY (no clear direction)
        - Otherwise → VOLATILE (unpredictable, avoid trading)
        """
        # Ensure ADX is calculated
        if 'adx' not in dataframe.columns:
            adx_result = ta.adx(dataframe['high'], dataframe['low'], dataframe['close'])
            if isinstance(adx_result, DataFrame):
                dataframe['adx'] = adx_result['ADX_14'] if 'ADX_14' in adx_result.columns else adx_result.iloc[:, 0]
            else:
                dataframe['adx'] = adx_result
        
        # Ensure ATR is calculated
        if 'atr' not in dataframe.columns:
            dataframe['atr'] = ta.atr(dataframe['high'], dataframe['low'], dataframe['close'], length=14)
        
        dataframe['atr_pct'] = dataframe['atr'] / dataframe['close']
        
        # Ensure BB width is calculated
        if 'bb_width' not in dataframe.columns:
            dataframe['bb_width'] = (dataframe['bb_upperband'] - dataframe['bb_lowerband']) / dataframe['bb_middleband']
        
        # Classify regime
        conditions = [
            (dataframe['adx'] > 25) & (dataframe['bb_width'] > 0.04),  # Strong trend
            (dataframe['adx'] < 20) & (dataframe['bb_width'] < 0.02),  # Sideway/consolidation
        ]
        choices = ['TREND', 'SIDEWAY']
        dataframe['market_regime'] = np.select(conditions, choices, default='VOLATILE')
        
        return dataframe

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Adds several different TA indicators to the given DataFrame
        """
        # Market Regime Detection - must be called after BB indicators are available
        # Will be calculated in feature_engineering after all indicators are ready
        return dataframe

    def feature_engineering_expand_all(self, dataframe: DataFrame, period: int, metadata: dict, **kwargs) -> DataFrame:
        """
        *Only functional with FreqAI enabled strategies*
        This function will automatically expand the defined features using the config defined
        'indicator_periods', 'include_timeframes', 'include_shifted_candles' and 'include_corr_pairlist'.
        In other words, a single value here will generate multiple features in the model.
        """
        
        # Add SMC, Sonic R, Moon Phases
        dataframe = SMCIndicators.add_all_indicators(dataframe)

        # Add your custom indicators here
        dataframe['%R'] = ta.willr(dataframe['high'], dataframe['low'], dataframe['close'])
        dataframe['mfi'] = ta.mfi(dataframe['high'], dataframe['low'], dataframe['close'], dataframe['volume'])
        dataframe['adx'] = ta.adx(dataframe['high'], dataframe['low'], dataframe['close'])['ADX_14']
        dataframe['rsi'] = ta.rsi(dataframe['close'])
        
        # Bollinger Bands
        bollinger = ta.bbands(dataframe['close'], length=20, std=2)
        dataframe['bb_lowerband'] = bollinger['BBL_20_2.0']
        dataframe['bb_middleband'] = bollinger['BBM_20_2.0']
        dataframe['bb_upperband'] = bollinger['BBU_20_2.0']
        
        dataframe["%-bb_width"] = (
            dataframe["bb_upperband"] - dataframe["bb_lowerband"]
        ) / dataframe["bb_middleband"]
        dataframe["%-close-bb_lower"] = dataframe["close"] / dataframe["bb_lowerband"]
        
        # Detect Market Regime (after all indicators are available)
        dataframe = self.detect_market_regime(dataframe)

        return dataframe

    def feature_engineering_expand_basic(self, dataframe: DataFrame, metadata: dict, **kwargs) -> DataFrame:
        """
        *Only functional with FreqAI enabled strategies*
        This function will automatically expand the defined features on the config defined
        `include_timeframes`, `include_shifted_candles`, and `include_corr_pairlist`.
        In other words, a single feature defined in this function
        will automatically expand to a total of
        `include_timeframes` * `include_shifted_candles` * `include_corr_pairlist`
        numbers of features added to the model.

        Features defined here will *not* be automatically multiplied by
        `indicator_periods_candles`

        All features must be prepended with `%` to be recognized by FreqAI internals.
        """
        dataframe["%-pct-change"] = dataframe["close"].pct_change()
        dataframe["%-raw_volume"] = dataframe["volume"]
        dataframe["%-raw_price"] = dataframe["close"]
        return dataframe

    def feature_engineering_standard(self, dataframe: DataFrame, metadata: dict, **kwargs) -> DataFrame:
        """
        *Only functional with FreqAI enabled strategies*
        This optional function will be called once with the dataframe of the base timeframe.
        This is the final chance to add features. The columns won't be modified.
        All features must be prepended with `%` to be recognized by FreqAI internals.
        """
        return dataframe

    def set_freqai_targets(self, dataframe: DataFrame, metadata: dict, **kwargs) -> DataFrame:
        """
        *Only functional with FreqAI enabled strategies*
        Required function to set the targets for the model.
        All targets must be prepended with `&` to be recognized by the FreqAI internals.
        """
        # We are trying to predict the price 20 candles into the future
        dataframe["&s-up_or_down"] = np.where(
            dataframe["close"].shift(-20) > dataframe["close"], 1, 0
        )
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Based on TA indicators, populates the entry signal for the given dataframe
        """
        # Debug: Print columns to see what FreqAI added
        # print(f"Columns available: {dataframe.columns.tolist()}")
        
        if self.config['freqai']['enabled']:
            # Check if prediction column exists
            prediction_col = '&s-up_or_down_mean'
            if prediction_col in dataframe.columns:
                dataframe.loc[
                    (
                        (dataframe['market_regime'] == 'TREND') &  # Only trade in TREND
                        (dataframe[prediction_col] > 0.6) &  # High confidence it goes up
                        (dataframe['volume'] > 0)
                    ),
                    'enter_long'] = 1
            else:
                pass
                # print(f"Warning: {prediction_col} not found in dataframe.")

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Based on TA indicators, populates the exit signal for the given dataframe
        """
        if self.config['freqai']['enabled']:
            prediction_col = '&s-up_or_down_mean'
            if prediction_col in dataframe.columns:
                 dataframe.loc[
                    (
                        (dataframe[prediction_col] < 0.4) & # Confidence it goes down
                        (dataframe['volume'] > 0)
                    ),
                    'exit_long'] = 1
        
        return dataframe
