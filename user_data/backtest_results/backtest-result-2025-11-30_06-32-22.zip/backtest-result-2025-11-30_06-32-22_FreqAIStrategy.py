# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file
# --- Do not remove these libs ---
import numpy as np
import pandas as pd
from pandas import DataFrame
from freqtrade.strategy import IStrategy, IntParameter
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

class FreqAIStrategy(IStrategy):
    """
    FreqAI Strategy example.
    """
    INTERFACE_VERSION = 3
    
    # Minimal ROI designed for the strategy.
    minimal_roi = {
        "60": 0.01,
        "30": 0.03,
        "0": 0.05
    }

    stoploss = -0.05
    trailing_stop = False
    timeframe = '5m'
    process_only_new_candles = True
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    # FreqAI attributes
    can_short = False

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Adds several different TA indicators to the given DataFrame
        """
        # Standard indicators for strategy logic (if any)
        # In FreqAI, we often rely on the prediction, but we can mix.
        return dataframe

    def feature_engineering_expand_all(self, dataframe: DataFrame, period: int, metadata: dict, **kwargs) -> DataFrame:
        """
        *Only functional with FreqAI enabled strategies*
        This function will automatically expand the defined features on the config defined
        `indicator_periods_candles`, `include_timeframes`, `include_shifted_candles`, and
        `include_corr_pairlist`.
        In other words, a single feature defined in this function
        will automatically expand to a total of
        `indicator_periods_candles` * `include_timeframes` * `include_shifted_candles` * `include_corr_pairlist`
        numbers of features added to the model.

        All features must be prepended with `%` to be recognized by FreqAI internals.
        """
        # RSI
        dataframe["%-rsi"] = ta.RSI(dataframe, timeperiod=period)

        # MFI
        dataframe["%-mfi"] = ta.MFI(dataframe, timeperiod=period)

        # ADX
        dataframe["%-adx"] = ta.ADX(dataframe, timeperiod=period)

        # Bollinger Bands
        bollinger = qtpylib.bollinger_bands(qtpylib.typical_price(dataframe), window=period, stds=2)
        dataframe["%-bb_lowerband"] = bollinger["lower"]
        dataframe["%-bb_middleband"] = bollinger["mid"]
        dataframe["%-bb_upperband"] = bollinger["upper"]
        dataframe["%-bb_width"] = (
            dataframe["%-bb_upperband"] - dataframe["%-bb_lowerband"]
        ) / dataframe["%-bb_middleband"]
        dataframe["%-close-bb_lower"] = dataframe["close"] / dataframe["%-bb_lowerband"]

        return dataframe

    def feature_engineering_expand_basic(self, dataframe: DataFrame, metadata: dict, **kwargs) -> DataFrame:
        """
        *Only functional with FreqAI enabled strategies*
        This function will automatically expand the defined features on the config defined
        `include_timeframes`, `include_shifted_candles`, and `include_corr_pairlist`.
        In other words, a single feature defined in this function
        will automatically expand to a total of
        `include_timeframes` * `include_shifted_candles` * `include_corr_pairlist`
        numbers of features added to the model.

        Features defined here will *not* be automatically multiplied by
        `indicator_periods_candles`

        All features must be prepended with `%` to be recognized by FreqAI internals.
        """
        dataframe["%-pct-change"] = dataframe["close"].pct_change()
        dataframe["%-raw_volume"] = dataframe["volume"]
        dataframe["%-raw_price"] = dataframe["close"]
        return dataframe

    def feature_engineering_standard(self, dataframe: DataFrame, metadata: dict, **kwargs) -> DataFrame:
        """
        *Only functional with FreqAI enabled strategies*
        This optional function will be called once with the dataframe of the base timeframe.
        This is the final chance to add features. The columns won't be modified.
        All features must be prepended with `%` to be recognized by FreqAI internals.
        """
        return dataframe

    def set_freqai_targets(self, dataframe: DataFrame, metadata: dict, **kwargs) -> DataFrame:
        """
        *Only functional with FreqAI enabled strategies*
        Required function to set the targets for the model.
        All targets must be prepended with `&` to be recognized by the FreqAI internals.
        """
        # We are trying to predict the price 20 candles into the future
        dataframe["&s-up_or_down"] = np.where(
            dataframe["close"].shift(-20) > dataframe["close"], 1, 0
        )
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Based on TA indicators, populates the entry signal for the given dataframe
        """
        # Debug: Print columns to see what FreqAI added
        # print(f"Columns available: {dataframe.columns.tolist()}")
        
        if self.config['freqai']['enabled']:
            # Check if prediction column exists
            prediction_col = '&s-up_or_down_mean'
            if prediction_col in dataframe.columns:
                dataframe.loc[
                    (
                        (dataframe[prediction_col] > 0.6) &  # High confidence it goes up
                        (dataframe['volume'] > 0)
                    ),
                    'enter_long'] = 1
            else:
                pass
                # print(f"Warning: {prediction_col} not found in dataframe.")

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Based on TA indicators, populates the exit signal for the given dataframe
        """
        if self.config['freqai']['enabled']:
            prediction_col = '&s-up_or_down_mean'
            if prediction_col in dataframe.columns:
                 dataframe.loc[
                    (
                        (dataframe[prediction_col] < 0.4) & # Confidence it goes down
                        (dataframe['volume'] > 0)
                    ),
                    'exit_long'] = 1
        
        return dataframe
